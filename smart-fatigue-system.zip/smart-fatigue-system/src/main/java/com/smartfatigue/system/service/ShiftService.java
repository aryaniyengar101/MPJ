package com.smartfatigue.system.service;

import com.smartfatigue.system.model.Shift;
import com.smartfatigue.system.model.Worker;

import com.smartfatigue.system.repository.ShiftRepository;
import com.smartfatigue.system.repository.WorkerRepository;

import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class ShiftService {

    private final ShiftRepository shiftRepository;
    private final WorkerRepository workerRepository;
    private final SleepDataService sleepDataService;

    public ShiftService(
            ShiftRepository shiftRepository,
            WorkerRepository workerRepository,
            SleepDataService sleepDataService
    ) {

        this.shiftRepository = shiftRepository;
        this.workerRepository = workerRepository;
        this.sleepDataService = sleepDataService;
    }

    public String toggleShift(String workerCode) {

        Worker worker = workerRepository
                .findByWorkerCode(workerCode)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Worker does not exist"
                        )
                );

        Shift activeShift =
                shiftRepository
                .findByWorkerAndShiftEndIsNull(worker)
                .orElse(null);

        if (activeShift != null) {

            activeShift.setShiftEnd(
                    LocalDateTime.now()
            );

            shiftRepository.save(activeShift);

            return "Shift ended for "
                    + worker.getName();
        }

        double sleepHours =
                sleepDataService
                .getSleepHours(workerCode);

        Shift newShift = new Shift(

                worker,

                LocalDateTime.now(),

                sleepHours
        );

        shiftRepository.save(newShift);

        return "Shift started for "
                + worker.getName();
    }
}
