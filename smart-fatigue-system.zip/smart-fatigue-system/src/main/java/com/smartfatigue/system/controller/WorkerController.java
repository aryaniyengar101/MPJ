package com.smartfatigue.system.controller;
import java.util.Map;
import java.util.HashMap;
import com.smartfatigue.system.model.Worker;
import com.smartfatigue.system.service.WorkerService;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/workers")
public class WorkerController {

    private final WorkerService workerService;

    public WorkerController(
            WorkerService workerService
    ) {

        this.workerService = workerService;
    }

    @PostMapping
    public Worker addWorker(
            @RequestBody Worker worker
    ) {

        return workerService.addWorker(worker);
    }

    @GetMapping
    public List<Worker> getAllWorkers() {

        return workerService.getAllWorkers();
    }

    @DeleteMapping("/{workerCode}")

public Map<String, String>
deleteWorker(

        @PathVariable String workerCode
) {

    workerService.deleteWorker(workerCode);

    Map<String, String> response =
            new HashMap<>();

    response.put(
            "message",

            "Worker removed successfully"
    );

    return response;
}
}
