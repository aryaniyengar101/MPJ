package com.smartfatigue.system.service;

import com.smartfatigue.system.model.Worker;
import com.smartfatigue.system.repository.WorkerRepository;
import com.smartfatigue.system.repository.ShiftRepository;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WorkerService {

    private final WorkerRepository workerRepository;
    private final ShiftRepository shiftRepository;

    public WorkerService(WorkerRepository workerRepository,
                         ShiftRepository shiftRepository) {

        this.workerRepository = workerRepository;
        this.shiftRepository = shiftRepository;
    }

    public Worker addWorker(Worker worker) {

        if (workerRepository.existsByWorkerCode(
                worker.getWorkerCode())) {

            throw new RuntimeException(
                    "Worker already exists"
            );
        }

        return workerRepository.save(worker);
    }

    public List<Worker> getAllWorkers() {
        return workerRepository.findAll();
    }

    public void deleteWorker(String workerCode) {

        Worker worker = workerRepository
                .findByWorkerCode(workerCode)
                .orElseThrow(() ->
                        new RuntimeException(
                                "Worker does not exist"
                        )
                );

        boolean activeShiftExists =
                shiftRepository
                .findByWorkerAndShiftEndIsNull(worker)
                .isPresent();

        if (activeShiftExists) {

            throw new RuntimeException(
                    "Cannot remove worker currently on shift"
            );
        }

        workerRepository.delete(worker);
    }
}
