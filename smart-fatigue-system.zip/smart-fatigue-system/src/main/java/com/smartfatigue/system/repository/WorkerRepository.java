package com.smartfatigue.system.repository;

import com.smartfatigue.system.model.Worker;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface WorkerRepository
        extends JpaRepository<Worker, Long> {

    Optional<Worker> findByWorkerCode(String workerCode);

    boolean existsByWorkerCode(String workerCode);
}
