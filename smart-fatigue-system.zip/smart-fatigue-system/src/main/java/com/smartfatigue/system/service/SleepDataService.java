package com.smartfatigue.system.service;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

@Service
public class SleepDataService {

    public double getSleepHours(String workerCode) {

        try {

            InputStream inputStream =
                    getClass()
                    .getResourceAsStream(
                            "/data/sleep_data.csv"
                    );

            BufferedReader reader =
                    new BufferedReader(
                            new InputStreamReader(
                                    inputStream
                            )
                    );

            String line;

            reader.readLine();

            while ((line = reader.readLine()) != null) {

                String[] data = line.split(",");

                String csvWorkerCode = data[0];

                double sleepHours =
                        Double.parseDouble(data[1]);

                if (csvWorkerCode.equals(workerCode)) {

                    return sleepHours;
                }
            }

        } catch (Exception e) {

            throw new RuntimeException(
                    "Error reading sleep data"
            );
        }

        throw new RuntimeException(
                "Sleep data not found"
        );
    }
}
