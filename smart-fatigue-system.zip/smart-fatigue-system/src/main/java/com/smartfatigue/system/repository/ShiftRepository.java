package com.smartfatigue.system.repository;

import com.smartfatigue.system.model.Shift;
import com.smartfatigue.system.model.Worker;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ShiftRepository
        extends JpaRepository<Shift, Long> {

    Optional<Shift> findByWorkerAndShiftEndIsNull(
            Worker worker
    );

    List<Shift> findByShiftEndIsNull();
}
