package com.smartfatigue.system;

import org.springframework.security
.crypto.bcrypt
.BCryptPasswordEncoder;

public class HashGen {

    public static void main(
            String[] args
    ) {

        BCryptPasswordEncoder
        encoder =

        new BCryptPasswordEncoder();

        System.out.println(

            encoder.encode(
                "fatigue123"
            )
        );
    }
}
