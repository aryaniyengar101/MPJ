package com.smartfatigue.system.model;

import jakarta.persistence.*;

@Entity
@Table(name = "admins")

public class Admin {

    @Id

    @GeneratedValue(
        strategy =
        GenerationType.IDENTITY
    )

    private Long id;

    @Column(unique = true)

    private String username;

    private String passwordHash;

    private String email;

    public Long getId() {

        return id;
    }

    public void setId(Long id) {

        this.id = id;
    }

    public String getUsername() {

        return username;
    }

    public void setUsername(
            String username
    ) {

        this.username = username;
    }

    public String getPasswordHash() {

        return passwordHash;
    }

    public void setPasswordHash(
            String passwordHash
    ) {

        this.passwordHash =
                passwordHash;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(
            String email
    ) {

        this.email = email;
    }
}
