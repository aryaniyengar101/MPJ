package com.smartfatigue.system.controller;

import com.smartfatigue.system.model.Shift;
import com.smartfatigue.system.repository.ShiftRepository;

import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.LocalDateTime;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {

    private final ShiftRepository shiftRepository;

    public DashboardController(
            ShiftRepository shiftRepository
    ) {

        this.shiftRepository = shiftRepository;
    }

    @GetMapping
    public List<Map<String, Object>>
    getDashboardData() {

        List<Shift> activeShifts =

                shiftRepository
                .findByShiftEndIsNull();

        List<Map<String, Object>> response =

                new ArrayList<>();

        for (Shift shift : activeShifts) {

            Map<String, Object> data =

                    new HashMap<>();

            long hoursWorked =

                    Duration.between(

                            shift.getShiftStart(),

                            LocalDateTime.now()

                    ).toHours();

            double fatigueScore =

                    (hoursWorked * 10)

                    +

                    ((8 -
                      shift.getSleepHours())

                      * 10);

            if (fatigueScore < 0) {

                fatigueScore = 0;
            }

            String fatigueStatus;

            if (fatigueScore >= 80) {

                fatigueStatus = "HIGH";
            }

            else if (fatigueScore >= 50) {

                fatigueStatus = "MEDIUM";
            }

            else {

                fatigueStatus = "LOW";
            }

            data.put(

                    "workerCode",

                    shift.getWorker()
                    .getWorkerCode()
            );

            data.put(

                    "workerName",

                    shift.getWorker()
                    .getName()
            );

            data.put(

                    "jobType",

                    shift.getWorker()
                    .getJobType()
            );

            data.put(

                    "hoursWorked",

                    hoursWorked
            );

            data.put(

                    "sleepHours",

                    shift.getSleepHours()
            );

            data.put(

                    "fatigueScore",

                    fatigueScore
            );

            data.put(

                    "fatigueStatus",

                    fatigueStatus
            );

            response.add(data);
        }

        return response;
    }
}
