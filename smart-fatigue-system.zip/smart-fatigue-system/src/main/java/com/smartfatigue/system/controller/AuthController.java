package com.smartfatigue.system.controller;

import com.smartfatigue.system.model.Admin;

import com.smartfatigue.system.repository.AdminRepository;

import com.smartfatigue.system.service.EmailService;

import com.smartfatigue.system.service.OtpService;

import jakarta.servlet.http.HttpSession;

import org.springframework.security
.crypto.bcrypt
.BCryptPasswordEncoder;

import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController

@RequestMapping("/auth")

public class AuthController {

    private final AdminRepository
    adminRepository;

    private final EmailService
    emailService;

    private final OtpService
    otpService;

    private final BCryptPasswordEncoder
    encoder =

    new BCryptPasswordEncoder();

    public AuthController(

            AdminRepository
            adminRepository,

            EmailService
            emailService,

            OtpService
            otpService
    ) {

        this.adminRepository =
                adminRepository;

        this.emailService =
                emailService;

        this.otpService =
                otpService;
    }

    @PostMapping("/login")

    public Map<String, String>

    login(

            @RequestBody

            Map<String, String>
            body,

            HttpSession session
    ) {

        String username =

                body.get(
                        "username"
                );

        String password =

                body.get(
                        "password"
                );

        Map<String, String>
        response =

        new HashMap<>();

        Admin admin =

                adminRepository

                .findByUsername(
                        username
                )

                .orElse(null);

        if (

                admin == null ||

                !encoder.matches(

                        password,

                        admin
                        .getPasswordHash()
                )
        ) {

            response.put(

                    "error",

                    "Invalid credentials"
            );

            return response;
        }

        String otp =

                otpService
                .generateOtp();

        session.setAttribute(

                "otp",

                otp
        );

        session.setAttribute(

                "pendingUser",

                username
        );

        emailService.sendOtp(

                admin.getEmail(),

                otp
        );

        response.put(

                "message",

                "OTP sent"
        );

        return response;
    }

    @PostMapping("/verify-otp")

    public Map<String, String>

    verifyOtp(

            @RequestBody

            Map<String, String>
            body,

            HttpSession session
    ) {

        String enteredOtp =

                body.get("otp");

        String sessionOtp =

                (String)

                session.getAttribute(
                        "otp"
                );

        Map<String, String>
        response =

        new HashMap<>();

        if (

                sessionOtp == null ||

                !sessionOtp.equals(
                        enteredOtp
                )
        ) {

            response.put(

                    "error",

                    "Invalid OTP"
            );

            return response;
        }

        session.setAttribute(

                "authenticated",

                true
        );

        session.removeAttribute(
                "otp"
        );

        response.put(

                "message",

                "Login successful"
        );

        return response;
    }

    @GetMapping("/check")

    public Map<String, Boolean>

    check(

            HttpSession session
    ) {

        Boolean authenticated =

                (Boolean)

                session.getAttribute(

                        "authenticated"
                );

        Map<String, Boolean>
        response =

        new HashMap<>();

        response.put(

                "authenticated",

                authenticated != null

                && authenticated
        );

        return response;
    }

    @PostMapping("/logout")

    public void logout(

            HttpSession session
    ) {

        session.invalidate();
    }
}
