package com.smartfatigue.system.model;

import jakarta.persistence.*;

@Entity
@Table(name = "workers")
public class Worker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "worker_code", unique = true, nullable = false)
    private String workerCode;

    @Column(nullable = false)
    private String name;

    @Column(name = "job_type", nullable = false)
    private String jobType;

    public Worker() {
    }

    public Worker(String workerCode, String name, String jobType) {
        this.workerCode = workerCode;
        this.name = name;
        this.jobType = jobType;
    }

    public Long getId() {
        return id;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJobType() {
        return jobType;
    }

    public void setJobType(String jobType) {
        this.jobType = jobType;
    }
}
