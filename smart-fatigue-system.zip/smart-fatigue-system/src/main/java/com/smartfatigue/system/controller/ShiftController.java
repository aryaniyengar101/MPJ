package com.smartfatigue.system.controller;

import com.smartfatigue.system.service.ShiftService;

import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/shift")
public class ShiftController {

    private final ShiftService shiftService;

    public ShiftController(
            ShiftService shiftService
    ) {

        this.shiftService = shiftService;
    }

    @PostMapping("/toggle")

    public Map<String, String>
    toggleShift(

            @RequestBody
            Map<String, String> body
    ) {

        String workerCode =
                body.get("workerCode");

        String result =
                shiftService.toggleShift(
                        workerCode
                );

        Map<String, String> response =
                new HashMap<>();

        response.put(
                "message",

                result
        );

        return response;
    }
}
