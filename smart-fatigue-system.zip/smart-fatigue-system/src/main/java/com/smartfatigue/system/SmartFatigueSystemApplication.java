package com.smartfatigue.system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartFatigueSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartFatigueSystemApplication.class, args);
	}

}
