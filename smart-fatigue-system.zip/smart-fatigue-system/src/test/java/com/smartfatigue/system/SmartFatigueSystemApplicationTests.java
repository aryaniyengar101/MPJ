package com.smartfatigue.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartFatigueSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
