package com.fatigue.system.service;

import org.springframework.stereotype.Service;

@Service
public class FatigueService {

public double calculateFatigue(double sleepHours, double workHours, String jobType) {

double decayFactor;

if (jobType.equalsIgnoreCase("pilot")) {
    decayFactor = 0.07;
} else {
    decayFactor = 0.04;
}
double effectiveSleep = sleepHours - (workHours * decayFactor);

if (effectiveSleep < 0) {
    effectiveSleep = 0;
}

double sleepDeficit = 8 - effectiveSleep;

if (sleepDeficit < 0) {
    sleepDeficit = 0;
}

double workWeight;

if (jobType.equalsIgnoreCase("pilot")) {
    workWeight = 2.5;
} else {
    workWeight = 1.8;
}

double fatigueScore = (sleepDeficit * 5) + (workHours * workWeight);

return fatigueScore;
}

public String getRisk(double score) {

if (score < 20) {
    return "SAFE";
} else if (score < 30) {
    return "WARNING";
} else {
    return "CRITICAL";
}
}

}
