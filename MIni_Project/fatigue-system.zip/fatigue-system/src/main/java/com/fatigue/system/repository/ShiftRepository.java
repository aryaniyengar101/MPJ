package com.fatigue.system.repository;

import com.fatigue.system.model.Shift;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ShiftRepository extends JpaRepository<Shift, Long> {

    // Get all active shifts
    List<Shift> findByShiftEndIsNull();

    // Check if worker already has active shift
    Optional<Shift> findByWorkerIdAndShiftEndIsNull(Long workerId);
}
