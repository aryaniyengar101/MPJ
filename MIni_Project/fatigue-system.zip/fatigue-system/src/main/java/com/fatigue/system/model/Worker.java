package com.fatigue.system.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Worker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String jobType;
}
