package com.fatigue.system.controller;

import com.fatigue.system.model.*;
import com.fatigue.system.repository.*;
import com.fatigue.system.service.FatigueService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;


@RestController
@CrossOrigin
public class MainController {


@Autowired
private WorkerRepository workerRepo;

@Autowired
private ShiftRepository shiftRepo;

@Autowired
private FatigueService fatigueService;

@PostMapping("/workers")
public Worker addWorker(@RequestBody Worker w) {
    return workerRepo.save(w);
}

@PostMapping("/shift/start")
public Object startShift(@RequestBody Map<String, Object> req) {

    Long workerId = Long.valueOf(req.get("workerId").toString());
    double sleepHours = Double.parseDouble(req.get("sleepHours").toString());

    // Check if worker already has active shift
   
   Optional<Worker> optWorker = workerRepo.findById(workerId);

if (optWorker.isEmpty()) {
    return Map.of("message", "Worker not found");
}

Worker w = optWorker.get();

 Optional<Shift> existing = shiftRepo.findByWorkerIdAndShiftEndIsNull(workerId);

    if (existing.isPresent()) {
        return Map.of("message", "Worker already has an active shift");
    }


    Shift s = new Shift();
    s.setWorker(w);
    s.setShiftStart(LocalDateTime.now());
    s.setSleepHours(sleepHours);

    return shiftRepo.save(s);
}

@PostMapping("/shift/end/{id}")
public String endShift(@PathVariable Long id) {

    Shift s = shiftRepo.findById(id).orElseThrow();

    s.setShiftEnd(LocalDateTime.now());
    shiftRepo.save(s);

    return "Shift ended";
}

@GetMapping("/dashboard")
public List<Map<String, Object>> getDashboard() {

    List<Shift> shifts = shiftRepo.findByShiftEndIsNull();
    List<Map<String, Object>> result = new ArrayList<>();

    for (Shift s : shifts) {

        Worker w = s.getWorker();

        double workHours = Duration.between(
                s.getShiftStart(),
                LocalDateTime.now()
        ).toMinutes() / 60.0;

        double fatigue = fatigueService.calculateFatigue(
                s.getSleepHours(),
                workHours,
                w.getJobType()
        );

        String risk = fatigueService.getRisk(fatigue);

        double maxHours = w.getJobType().equalsIgnoreCase("pilot") ? 8 : 10;
        double timeLeft = maxHours - workHours;

        Map<String, Object> row = new HashMap<>();
        row.put("name", w.getName());
        row.put("jobType", w.getJobType());
        row.put("workHours", workHours);
        row.put("fatigue", fatigue);
        row.put("risk", risk);
        row.put("timeLeft", timeLeft);
        row.put("shiftId", s.getId());

        result.add(row);
    }

    return result;
}

@GetMapping("/workers")
public List<Worker> getAllWorkers() {
    return workerRepo.findAll();
}

}
