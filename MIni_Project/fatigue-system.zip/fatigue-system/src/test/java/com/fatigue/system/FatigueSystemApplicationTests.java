package com.fatigue.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FatigueSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
